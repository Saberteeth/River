import * as React from 'react';


interface Props {
  name: string,
  number?: number,
}

class Test extends React.Component<Props, Object> {
  render() {
    const { name, number = 1 } = this.props;
    return (
      <span>{`${name}:${number}`}</span>
    )
  }
}

export default Test;
