import * as React from 'react';
import './App.css';
import { createActivity, MainActivity } from './HelloWorld/Main';
import Title from './HelloWorld/Title';

class App extends React.Component {
  main: MainActivity | null = null;

  public render() {
    return (
      <div className="App">
        <Title name="Hello World" />
        <canvas width="400" height="400" id="helloworld" />
        <div className="list">
          <h2>Demos</h2>
          <List />
        </div>
      </div>
    );
  }

  public componentDidMount() {
    if (!this.main) {
      this.main = createActivity('helloworld');
      this.main.onCreate();
    }
  }
}

function List() {
  return (<ul>
    <li><a href="game/index.html">Gomoku</a></li>
  </ul>)
}

export default App;
