import river from '../class/index';
export default interface iAnimations {
    over: (v: river.View) => void;
}
