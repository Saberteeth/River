# README
**version: 3.0.2**

一个可定制前端图形引擎。仅通过三个Class和三个Interface提供一系列动画、事件触发、渲染等功能和定制。因为沿用typescript开发，因此对java程序员也非常友好。

## Install
```js
// 首先安装nodeJs
// 在项目根目录下打开控制台或终端
// 输入如下指令，该安装库所属nodeJs需要访问境外网站，如果太慢可以考虑先翻墙再npm install
npm install
// 安装成功后输入如下指令，即可访问localhost:3000浏览demo.
npm run start
```

## Description
### Interface
- iContainer[iC]
> 容器接口，实现该接口后即可处理事件传递和子view管理。

- iAnimations[iA]
> 动画接口，实现该接口后即可进行动画算法。

- iLayout[iL]
> 布局接口，实现该接口可对子View制定布局。

### Views
- Activity[iC]
> Stage对象，负责Canvas事件的初始化和子对象管理，可以理解为它是一个超级Container

- View
> 原子对象，除Activity以外所有视图组件都直接或间接继承至View。

  - Container[iC]

        > 容器对象，既实现了iC的View，使其可以作为容器装载其他子View。例：ListView

### Animations
- Alpha[iA]
- Trans[iA]

### Layouts
接口已存在，暂无实现

## Demo
项目Demo包含了除 Layouts 以外的所有功能基本实现案例。
下部只是一个基础预览。
```js
class MainActivity extends view.Activity{
  	private btn: widget.Button;
  	onCreate(){
  		this.btn = new widget.Button();
  		this.btn.txt = "Button";
  		this.btn.addClickEvent(()=>{
  			console.log("button adction!");
  		})
  		this.addchild(this.btn);
  	}
}
```


