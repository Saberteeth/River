import Activity from './view/Activity';
import Container from './view/Container';
import View from './view/View';

export default {
  Activity,
  Container,
  View,
}

