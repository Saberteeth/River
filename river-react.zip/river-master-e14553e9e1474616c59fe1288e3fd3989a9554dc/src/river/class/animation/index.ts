import Alpha from './Alpha';
import Trans from './Trans';

export default {
  Alpha, Trans
}
