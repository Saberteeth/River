import * as view from '../class/output';

export default interface iAnimations {
  over: (v: view.View) => void;
}
