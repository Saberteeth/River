export default {
  SET_LOGIN_STATUS: 'SET_LOGIN_STATUS'
}
