import * as React from 'react';
import './App.css';
import { createActivity, MainActivity } from './HelloWorld/Main';
import Title from './HelloWorld/Title';

var moment = require('moment');

class App extends React.Component {
  main: MainActivity | null = null;

  public render() {
    return (
      <div className="App">
        <Title name="Hello World" />
        <div className="iphone">
          <div className="head">
          <div style={{float: 'left'}}>中国移动</div>
          <div style={{float: 'right'}}>
            {moment().format("a h:mm").replace('am','上午').replace('pm','下午')}
          </div>
          </div>
          <canvas width="400" height="600" id="helloworld" />
        </div>
        <div className="list">
          <h2>Other</h2>
          <List />
        </div>
      </div>
    );
  }

  public componentDidMount() {
    if (!this.main) {
      this.main = createActivity('helloworld');
      this.main.onCreate();
    }
  }
}


function List() {
  return (<ul>
    <li><a href="API.htm">API</a></li>
    <li><a href="game/index.html">Gomoku</a></li>
  </ul>)
}

export default App;
