import river from '../river/class';

import { Move, AnimationUtils } from './Move';
import { Setting } from './Setting';


export class MainActivity extends river.Activity {
  private btn: Move;
  private setting: Setting;

  public onCreate() {
    this.btn = new Move();
    this.setting = new Setting();
    const endL = this.width / 2 - 250 / 2;
    const endT = this.height / 2 - 150 / 2;

    this.setting.left = endL;
    this.setting.top = endT;

    this.btn.left = this.width / 2 - this.btn.width / 2;
    this.btn.top = this.height / 2 - this.btn.height / 2;

    this.setting.bindOver(()=>{
      this.removeChild(this.setting);
      this.addChild(this.btn);
    });


    this.btn.onClick = () => {
      this.removeChild(this.btn);
      this.addChild(this.setting);
      this.setting.showItem(this.btn.left, this.btn.top, endL, endT);
    }

    this.setting.addTouchEventListener(e=>{
      if(e.type == 'mouseup') {
        this.setting.closeItem(endL, endT, this.btn.left, this.btn.top);
      }
      return true;
    });

    // this.addChild(this.setting);
    this.addChild(this.btn);


    AnimationUtils.ALPHA.play(0, 0.5, 1000, this.btn);
  }

}

export function createActivity(id: string) {
  return new MainActivity(<HTMLCanvasElement>document.getElementById(id));
}

export default createActivity;


