declare enum ViewType {
    CHANGE = 0,
    SUCCESS = 1
}
export default ViewType;
