import river from '../class/index';
river.View;
export default interface iAnimations {
  over: (v: river.View) => void;
}
