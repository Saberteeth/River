/**
   * 布局器
   */
interface iLayout {
    margin: number;
    useLayout(): void;
}
export default iLayout;
